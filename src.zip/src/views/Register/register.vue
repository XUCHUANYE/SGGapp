<template>
  <div>注册</div>
</template>

<script>
export default {
  name: "register",
  data() {
    return {};
  },
  components: {},
};
</script>

<style scoped lang="">
</style>
