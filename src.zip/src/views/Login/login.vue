<template>
  <div>
    <h1>登录</h1>
  </div>
</template>

<script>
export default {
  name: "login",
  data() {
    return {};
  },
  components: {},
};
</script>

<style scoped lang="">
</style>
